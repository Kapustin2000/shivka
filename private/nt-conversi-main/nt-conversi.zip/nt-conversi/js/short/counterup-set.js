jQuery(document).ready(function($) {
	"use strict";  
	jQuery('.affa-counter-txt > h4').counterUp({
		delay: 10,
		time: 3000
	});

});