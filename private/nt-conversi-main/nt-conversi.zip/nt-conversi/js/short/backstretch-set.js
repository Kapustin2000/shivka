/*
  Author: Lumberjacks
  Template: Sawmill (HTML Template)
  Version: 1.0
  URL: http://themeforest.net/user/Lumberjacks/
*/

"use strict";

jQuery(document).ready(function (){

  // backstretch
  jQuery("header").backstretch(prefix.headerbg);
});